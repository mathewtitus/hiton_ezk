def tester():
	print("Testing... 1 2 3....")


